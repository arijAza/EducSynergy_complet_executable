package com.example.demo.Controllers;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Services.CoursService;
import com.example.demo.classes.Cours;
@RestController
@RequestMapping("/api/cours")
@CrossOrigin(origins = "*", maxAge = 3600)
public class CoursController {

 CoursService coursService;

    public CoursController(CoursService coursService) {
        this.coursService = coursService;
    }
    
    
    // fct ajout cours
    @PostMapping("/ajouterCours")
    public void ajouterCours(@RequestBody Cours cours) {
    	coursService.ajouterCours(cours);
    	
    }
    
    // fct afficher cours
    @GetMapping("/ConsulterCours")
    public List<Cours> getCours() {
        return coursService.getAllCours();
    }
    
    
    
    // fct modifier cours
    @PutMapping("/ModifierCours/{id}")
    public void updateCours (@RequestBody Cours cours, @PathVariable long id){
    	coursService.updateCours(cours,id);
    }


     

}

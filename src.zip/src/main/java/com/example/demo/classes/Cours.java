 package com.example.demo.classes;
import java.io.Serializable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
@Entity
public class Cours implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @ManyToOne
    @JoinColumn(name = "admin_id")
    private Admin admin;
 
    public String getNomDuCours() {
		return nomDuCours;
	}
	public void setNomDuCours(String nomDuCours) {
		this.nomDuCours = nomDuCours;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCoursFormatPdf() {
		return coursFormatPdf;
	}
	public void setCoursFormatPdf(String coursFormatPdf) {
		this.coursFormatPdf = coursFormatPdf;
	}
	public String getCoursFormatVideo() {
		return coursFormatVideo;
	}
	public void setCoursFormatVideo(String coursFormatVideo) {
		this.coursFormatVideo = coursFormatVideo;
	}
	public String getNomProfesseur() {
		return nomProfesseur;
	}
	public void setNomProfesseur(String nomProfesseur) {
		this.nomProfesseur = nomProfesseur;
	}
	@ManyToOne
    @JoinColumn(name = "enseignant_id")
    private Enseignant enseignant ;
    private String nomDuCours;
    private String description;
    private String coursFormatPdf;
    private String coursFormatVideo;
    private String nomProfesseur;

}

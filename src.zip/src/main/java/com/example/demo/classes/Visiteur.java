package com.example.demo.classes;

import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
@Inheritance(strategy=InheritanceType.JOINED)
public class Visiteur {
    private String nom;
    private String prenom;
    private String numTel;
    private String adresseMail;


    public Visiteur() {
    }

    public Visiteur(String nom, String prenom, String numTel, String adresseMail) {
        this.nom = nom;
        this.prenom = prenom;
        this.numTel = numTel;
        this.adresseMail = adresseMail;
    }
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNumTel() {
        return numTel;
    }

    public void setNumTel(String numTel) {
        this.numTel = numTel;
    }

    public String getAdresseMail() {
        return adresseMail;
    }

    public void setAdresseMail(String adresseMail) {
        this.adresseMail = adresseMail;
    }
}


package com.example.demo.Services;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;
import com.example.demo.Repositories.CoursRepository;
import com.example.demo.classes.Cours;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.server.ResponseStatusException;




@Service
public class CoursService {
	@Autowired

     private  CoursRepository coursRepository;
	 // private String ch="cours inexistant";
    
	 public CoursService(CoursRepository coursRepository) {
        this.coursRepository = coursRepository;
    }

	 // ajouter cours
	 public Cours ajouterCours(Cours cours) {
        return coursRepository.save(cours);
    }
	 
	 // get cours
    public List<Cours> getAllCours() {
        return coursRepository.findAll();
    }
      
    // modifier cours
    public boolean updateCours(Cours cours, long id) {
            Optional<Cours> coursOptional = coursRepository.findById((long) id);
            
            if (coursOptional.isPresent()) {
                Cours coursToUpdate = coursOptional.get();
                
                // Mettre à jour les champs du cours avec les nouvelles valeurs
                coursToUpdate.setNomDuCours(cours.getNomDuCours());
                coursToUpdate.setDescription(cours.getDescription());
                coursToUpdate.setCoursFormatPdf(cours.getCoursFormatPdf());
                coursToUpdate.setCoursFormatVideo(cours.getCoursFormatVideo());
                coursToUpdate.setNomProfesseur(cours.getNomProfesseur());
                
                
                // Enregistrer les modifications dans la base de données
                coursRepository.save(coursToUpdate);
                return true;
            } else 
            	return false ;  
        }

    //modifier methode 2
 //   public void updateCours(@RequestBody Cours cours,@PathVariable long id)
   //  {
    //	coursService.updateCours(cours,id);
     // }
     
}


    
    //    @PutMapping("/{id}")
  //  public ResponseEntity<Cours> modifierCours(@PathVariable Long id, @RequestBody Cours coursDetails) {
    //    Cours cours = CoursService.getCoursById(id);

      //  if (cours == null) {
        //    return ResponseEntity.notFound().build();
        //}

        // Mettre à jour les champs du cours avec les détails fournis
        //cours.setNomDuCours(coursDetails.getNomDuCours());
       // cours.setDescription(coursDetails.getDescription());
        //cours.setCoursFormatPdf(coursDetails.getCoursFormatPdf());
        //cours.setCoursFormatVideo(coursDetails.getCoursFormatVideo());
        //cours.setNomProfesseur(coursDetails.getNomProfesseur());

        // Enregistrer la mise à jour dans la base de données
        //Cours coursMisAJour = CoursService.enregistrerCours(cours);
        //return ResponseEntity.ok(coursMisAJour);
    //}



      

//private static Cours getCoursById(Long id) {
    //return CoursRepository.findById(id).orElse(null);
	//}

//private static Cours enregistrerCours(Cours cours) {
  //  return CoursRepository.save(cours);

//}


